import sys
from Adafruit_IO import MQTTClient
from sense_hat import SenseHat
from time import asctime, sleep

sense = SenseHat()

# 🔑 Adafruit IO credentials
ADAFRUIT_IO_KEY = 'aio_LZwa59aXbBweknWvpVtQM9J5fAp8'
ADAFRUIT_IO_USERNAME = 'jayanth_cr05'

# 🧠 Feed names
FEED_X = 'x_button'
FEED_Y = 'y_button'

# 📁 Log file
LOG_FILE = '/home/pi/Documents/accel_log.txt'

# ------------------ LOGGING FUNCTION ------------------
def log_data(message):
    """Log message to file in your studied format."""
    log = open(LOG_FILE, 'a')
    now = str(asctime())
    log.write(now + " " + message + "\n")
    print(message)
    log.close()
    sleep(30)

# ------------------ CALLBACKS ------------------
def connected(client):
    print("✅ Connected to Adafruit IO!")
    print(f"Listening for {FEED_X} and {FEED_Y} feed changes...")
    client.subscribe(FEED_X)
    client.subscribe(FEED_Y)

def disconnected(client):
    print("❌ Disconnected from Adafruit IO")
    sys.exit(1)

def message(client, feed_id, payload):
    print(f"Feed {feed_id} received new value: {payload}")

    accel = sense.get_accelerometer_raw()
    x = round(accel['x'], 3)
    y = round(accel['y'], 3)

    if feed_id == FEED_X and payload == "1":
        msg = f"X-Axis Acceleration: {x}"
        log_data(msg)
        sense.show_message(f"X:{x}", scroll_speed=0.05)

    elif feed_id == FEED_Y and payload == "1":
        msg = f"Y-Axis Acceleration: {y}"
        log_data(msg)
        sense.show_message(f"Y:{y}", scroll_speed=0.05)

# ------------------ MAIN PROGRAM ------------------
client = MQTTClient(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)
client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message

client.connect()
client.loop_blocking()