import urllib.request
import requests
import threading
import json
import random
from sense_hat import SenseHat

sense = SenseHat()

def thingspeak_post():
    threading.Timer(5, thingspeak_post).start()
    val1,val2 = sense.get_temperature(),sense.get_humidity()
    URL = 'https://api.thingspeak.com/update?api_key='
    KEY = 'HLYHTOV6X1E3DRVW' # Enter the API Write Key from ThingSpeak
    HEADER = '&field1={}&field2={}'.format(val1,val2)
    NEW_URL = URL + KEY + HEADER
    print(NEW_URL)
    data = urllib.request.urlopen(NEW_URL)
    print(data)
    
if __name__ == '__main__':
    thingspeak_post()



import urllib.request
import requests
import json
import random
import threading
from sense_hat import SenseHat

sense=SenseHat()

def thingspeak_post():
    threading.Timer(5,thingspeak_post).start()
    val1=round(sense.get_temperature(),2)
    val2=round(sense.get_humidity(),2)
    URL = 'https://api.thingspeak.com/update?api_key='
    KEY = 'HLYHTOV6X1E3DRVW' 
    HEADER="&field1={}&field2={}".format(val1,val2)
    NEW_URL=URL+KEY+HEADER
    print(NEW_URL)
    data=urllib.request.urlopen(NEW_URL)
    print(data)

if __name__=='__main__':
    thingspeak_post()

    
