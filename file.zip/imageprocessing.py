from PIL import Image, ImageTk, ImageFilter, ImageEnhance
import tkinter as tk

def blur_image(val):
    blur = ImageFilter.GaussianBlur(radius = float(val))
    img = im.filter(blur)
    photo = ImageTk.PhotoImage(img)
    l['image']=photo
    l.photo = photo

def rotate_image(val):
    img = im.rotate(float(val))
    photo = ImageTk.PhotoImage(img)
    l['image']=photo
    l.photo = photo

def resize_image(val): # 0 to 128
    img = im.resize((int(val), int(val)))
    photo = ImageTk.PhotoImage(img)
    l['image']= photo
    l.photo = photo

def enhance_image(val): #0 to 2
    enhancer = ImageEnhance.Color(im)
    img = enhancer.enhance(float(val))
    photo = ImageTk.PhotoImage(img)
    l['image'] = photo
    l.photo = photo

root = tk.Tk()

im = Image.open(r"sample2.png")

photo = ImageTk.PhotoImage(im)
l = tk.Label(root, image=photo)
l.grid(row=0,column=1)
l.photo = photo

rotation_scale = tk.Scale(root, label="Angle", from_=0, to=360,resolution=1, orient=tk.VERTICAL,command=rotate_image)
rotation_scale.grid(row=0,column=0)

blur_scale = tk.Scale(root, label="Blur Radius", from_=0, to=10,resolution=1, orient=tk.VERTICAL,command=blur_image)
blur_scale.grid(row=0,column=2)

enhance_scale=tk.Scale(root,label='Enhance',from_=0, to=2,resolution=0.1,command=enhance_image,orient=tk.HORIZONTAL)
enhance_scale.grid(row=1,column=1)



root.mainloop()
