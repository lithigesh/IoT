from azure.iot.device import IoTHubDeviceClient, Message
import time
import random
# Replace this with your IoT Hub device connection string

CONNECTION_STRING = "HostName=prathista-123.azure-devices.net;DeviceId=dev1;SharedAccessKey=0JGR9rtQniHmDBWB7OEXMdGlqXYM+mRSZeyINEovuqs="


# Create IoT Hub client
client = IoTHubDeviceClient.create_from_connection_string(CONNECTION_STRING)
print(" IoT Device Simulator started...")
try:
    for i in range(10): # send 10 messages (avoid infinite loop in notebooks)
        temperature = round(random.uniform(20.0, 30.0), 2)
        humidity = round(random.uniform(40.0, 60.0), 2)
        msg = Message(f'{{"temperature": {temperature}, "humidity": {humidity}}}')
        msg.content_type = "application/json"
        msg.content_encoding = "utf-8"
        client.send_message(msg)
        print(f" Sent message: {msg}")
        time.sleep(2)

except Exception as e:
    print("Error:", e)
finally:
    client.disconnect()
    print(" Simulation stopped")





from azure.iot.device import IOTHubDeviceClient,Message
from sense_hat import SenseHat
import time

sense=SenseHat()

CONNECTION_STRING="HostName=prathista-123.azure-devices.net;DeviceId=dev1;SharedAccessKey=0JGR9rtQniHmDBWB7OEXMdGlqXYM+mRSZeyINEovuqs="

client=IOTHubDeviceClient.create_from_connection_string(CONNECTION_STRING)
print('Iot simulator started')
try:
    for i in range(10):
        temp=round(sense.get_temperature(),2)
        pressure=round(sense.get_pressure(),2)
        msg=Message(f'{{"temperature":{temperature}," pressure": {pressure}}}')
        msg.content_type='application/json'
        msg.content_encoding='utf-8'
        client.send_message(msg)
        print(f"sent message:{msg}")
        time.sleep(0.2)

except Exception as e:
    print('Error:',e)

finally:
    client.disconnect()
    print('Iot simulator disconnected')
