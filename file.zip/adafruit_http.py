import time
from Adafruit_IO import Client, Feed
from sense_hat import SenseHat

sense = SenseHat()

# Delay in between sensor readings in seconds
READ_TIMEOUT = 5

# Set to your Adafruit IO Key
ADAFRUIT_IO_KEY = 'aio_SWnQ06Xx4Y7Tc2YyvdWPkrM0h23b'

# Set your Adafruit IO username
ADAFRUIT_IO_USERNAME = 'Veankat'

# Create an instance of the Rest client
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

# Set up Adafruit IO Feeds
temperature_feed = aio.feeds('temperature')
humidity_feed = aio.feeds('humidity')

while True:
    temperature = sense.get_temperature_from_humidity()
    humidity = sense.get_humidity()
    if humidity is not None and temperature is not None:
        print('Temp = {0:0.1f}*C Humidity = {1:0.1f}%'.format(temperature, humidity))
        # Format values
        temperature_str = f"{temperature:.2f}"
        humidity_str = f"{humidity:.2f}"
        # Send humidity and temperature feeds to Adafruit IO
        aio.send(temperature_feed.key, temperature_str)
        aio.send(humidity_feed.key, humidity_str)
    else:
        print('Failed to get Temperature and Humidity from SenseHat')
    # timeout to avoid flooding adafruit io
    time.sleep(READ_TIMEOUT)
