import sys
from Adafruit_IO import MQTTClient
from sense_hat import SenseHat

sense=SenseHat()

ADAFRUIT_IO_KEY='aio_eOQe94iNuDHvqVhp2MqkP0Skm8aG'
ADAFRUIT_IO_USERNAME='praveen_s'
FEED_ID1='iotdev'
FEED_ID2='iotani'
def connected(client):
    print('Connected to Adafruit IO! Listening for {0} changes...'.format(FEED_ID1))
    client.subscribe(FEED_ID1)  
def disconnected(client):
    print('Disconnected from Adafruit IO!')
    sys.exit(1)
def message(client,feed_id,payload):
    print(f'received new value: {payload}')
    if payload=="1":
        print("Light ON")
        sense.show_letter("O")
        val=round(sense.get_temperature(),1)
        client.publish(FEED_ID2,str(val))
    if payload=="0":
        print("Light OFF")
        sense.clear()
client=MQTTClient(ADAFRUIT_IO_USERNAME,ADAFRUIT_IO_KEY)
client.on_connect=connected
client.on_disconnect=disconnected
client.on_message=message
client.connect()
client.loop_blocking()