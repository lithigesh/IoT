// Include the header file for TM4C123GH6PM register definitions
#include "TM4C123GH6PM.h"

// Include FreeRTOS kernel header files
#include "FreeRTOS.h"
#include "task.h"

//---------------------------------------------------------------------
// Function Prototypes — declare before main()
//---------------------------------------------------------------------
void delayMs(int n);
void vTask1(void *pvParameters);
void vTask2(void *pvParameters);
void vTask3(void *pvParameters);

//---------------------------------------------------------------------
// Simple delay function (for clock stabilization after enabling GPIO)
//---------------------------------------------------------------------
void delayMs(int n)
{
    volatile int i, j;
    for (i = 0; i < n; i++)
        for (j = 0; j < 3180; j++); // ~1ms delay for 16MHz system clock
}

//---------------------------------------------------------------------
// TASK 1: RED LED CONTROL (PF1)
// Blinks with a total period of 500 ms
// ON time = 200 ms, OFF time = 300 ms
// Priority = 3 (Highest among the three tasks)
//---------------------------------------------------------------------
void vTask1(void *pvParameters)
{
    while (1)
    {
        GPIOF->DATA |= (1 << 1);        // Turn ON RED LED (PF1 = 1)
        vTaskDelay(pdMS_TO_TICKS(200)); // Delay for 200 ms (LED ON)
        GPIOF->DATA &= ~(1 << 1);       // Turn OFF RED LED (PF1 = 0)
        vTaskDelay(pdMS_TO_TICKS(300)); // Delay for 300 ms (LED OFF)
        // Total period = 200 + 300 = 500 ms
    }
}

//---------------------------------------------------------------------
// TASK 2: BLUE LED CONTROL (PF2)
// Blinks with a total period of 800 ms
// ON time = 300 ms, OFF time = 500 ms
// Priority = 2 (Medium priority)
//---------------------------------------------------------------------
void vTask2(void *pvParameters)
{
    while (1)
    {
        GPIOF->DATA |= (1 << 2);        // Turn ON BLUE LED (PF2 = 1)
        vTaskDelay(pdMS_TO_TICKS(300)); // Delay for 300 ms (LED ON)
        GPIOF->DATA &= ~(1 << 2);       // Turn OFF BLUE LED (PF2 = 0)
        vTaskDelay(pdMS_TO_TICKS(500)); // Delay for 500 ms (LED OFF)
        // Total period = 300 + 500 = 800 ms
    }
}

//---------------------------------------------------------------------
// TASK 3: GREEN LED CONTROL (PF3)
// Blinks with a total period of 1000 ms
// ON time = 400 ms, OFF time = 600 ms
// Priority = 1 (Lowest priority)
//---------------------------------------------------------------------
void vTask3(void *pvParameters)
{
    while (1)
    {
        GPIOF->DATA |= (1 << 3);        // Turn ON GREEN LED (PF3 = 1)
        vTaskDelay(pdMS_TO_TICKS(400)); // Delay for 400 ms (LED ON)
        GPIOF->DATA &= ~(1 << 3);       // Turn OFF GREEN LED (PF3 = 0)
        vTaskDelay(pdMS_TO_TICKS(600)); // Delay for 600 ms (LED OFF)
        // Total period = 400 + 600 = 1000 ms
    }
}

//---------------------------------------------------------------------
// MAIN FUNCTION
//---------------------------------------------------------------------
int main(void)
{
    // 1️⃣ Enable clock for Port F (bit 5 in RCGCGPIO register)
    SYSCTL->RCGCGPIO |= (1 << 5);
    delayMs(1); // Wait for clock stabilization

    // 2️⃣ Configure PF1, PF2, and PF3 as digital outputs (LED pins)
    GPIOF->DIR |= (1 << 1) | (1 << 2) | (1 << 3); // Set direction as output
    GPIOF->DEN |= (1 << 1) | (1 << 2) | (1 << 3); // Enable digital function

    // 3️⃣ Create FreeRTOS Tasks
    //    Syntax: xTaskCreate(task_function, name, stack_size, parameters, priority, handle)

    xTaskCreate(vTask1,                 // Task function to be executed
                "RedLED",               // Name (for debugging)
                configMINIMAL_STACK_SIZE, // Stack size (in words, not bytes)
                NULL,                   // Parameters to pass (none here)
                3,                      // Task priority (higher = more priority)
                NULL);                  // Task handle (not used here)

    xTaskCreate(vTask2, "BlueLED", configMINIMAL_STACK_SIZE, NULL, 2, NULL);
    xTaskCreate(vTask3, "GreenLED", configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    // 4️⃣ Start the FreeRTOS Scheduler
    vTaskStartScheduler(); // Starts task switching — the RTOS takes control

    // 5️⃣ The program should never reach here unless scheduler fails
    while (1)
    {
        // Infinite loop
}
    return 0;
}
