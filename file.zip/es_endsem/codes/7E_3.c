#include "TM4C123GH6PM.h"

// This function performs the one-time setup for the timer.
void Timer0A_Init_1sec_Periodic(void)
{
    SYSCTL->RCGCTIMER |= 0x01;    // 1. Enable clock for Timer 0
    TIMER0->CTL = 0;             // 2. Disable Timer A during setup
    TIMER0->CFG = 0x00;          // 3. Configure for 32-bit timer mode
    TIMER0->TAMR = 0x02;         // 4. Configure for Periodic mode (timer reloads automatically)
    TIMER0->TAILR = 16000000 - 1;// 5. Set reload value for 1 second (@ 16MHz)
    TIMER0->ICR = 0x01;          // 6. Clear the Timer A timeout flag
    TIMER0->CTL = 0x01;          // 7. Enable Timer A and start counting
}

int main(void)
{
    int led_value = 0x02;       // Holds the current LED color (start with Red)
    int is_toggling = 0;        // Our state flag: 0 = Off, 1 = Toggling

    // --- GPIO Port F Setup (Switches & LEDs) ---
    SYSCTL->RCGCGPIO |= 0x20;
    GPIOF->LOCK = 0x4C4F434B;   // Unlock Port F to allow changes to PF0
    GPIOF->CR = 0x1F;           // Enable commit for all 5 pins on Port F
    GPIOF->DIR = 0x0E;          // Set PF1, PF2, PF3 (LEDs) as outputs
    GPIOF->DEN = 0x1F;          // Enable digital function for LEDs and switches
    GPIOF->PUR = 0x11;          // Enable pull-up resistors for PF0 (SW2) and PF4 (SW1)

    // --- One-time Timer Setup ---
    Timer0A_Init_1sec_Periodic();

    while(1)
    {
        // --- Input Reading Section ---
        // Read the state of the switches. The pull-up makes them 0 when pressed.
        int sw1_pressed = (GPIOF->DATA & 0x10) == 0;
        int sw2_pressed = (GPIOF->DATA & 0x01) == 0;

        // --- State Logic Section ---
        if (sw1_pressed)
        {
            is_toggling = 1; // If SW1 is pressed, set the state to "toggling".
        }
        if (sw2_pressed)
        {
            is_toggling = 0; // If SW2 is pressed, set the state to "off".
            GPIOF->DATA &= ~0x0E; // Immediately turn off all LEDs.
        }

        // --- Action Section (Non-Blocking) ---
        // Check two conditions: are we in the toggling state AND has the timer finished 1 second?
        if (is_toggling && (TIMER0->RIS & 0x01))
        {
            TIMER0->ICR = 0x01; // Clear the timer flag to reset the 1-second countdown.

            // Toggle the LED. The XOR operator (^) flips the bits.
            // This will turn the LED on if it's off, and off if it's on.
            GPIOF->DATA ^= led_value;
        }
    }
}