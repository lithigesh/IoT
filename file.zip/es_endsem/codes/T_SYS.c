#include "TM4C123GH6PM.h"

int main(void)
{
    int c = 0; // Initialize counter to 0

    // GPIO Port F setup for LEDs
    SYSCTL->RCGCGPIO |= 0x20; // Enable clock for Port F
    GPIOF->DIR = 0x0E;       // Set PF1, PF2, PF3 (LEDs) as output
    GPIOF->DEN = 0x0E;       // Enable digital function for LED pins

    // SysTick Timer setup
    SYSTICK->LOAD = 8000000 - 1; // Load value for 0.5 second delay (assuming 16 MHz clock)
    SYSTICK->CTRL = 5;           // Enable SysTick with system clock, no interrupts

    while(1)
    {
        // Check Bit 16 (COUNTFLAG) of the SysTick Control Register
        if (SYSTICK->CTRL & 0x10000)
        {
            // The flag is set, meaning 0.5 seconds have passed
            GPIOF->DATA = c << 1; // Display counter on LEDs (PF1, PF2, PF3)
            c++;                  // Increment the counter for the next cycle
        }
    }
}

/*
Time for One Systick period, T = (LOAD + 1)/ clock

| Desired Delay   | Formula                  | `LOAD` Value   | Explanation                   |
| --------------- | ------------------------ | -------------- | ----------------------------- |
| 1 second        | (1 × 16,000,000) − 1     | **15,999,999** | Full 1 second delay           |
| 0.5 seconds     | (0.5 × 16,000,000) − 1   | **7,999,999**  | Half second delay (your code) |
| 0.25 seconds    | (0.25 × 16,000,000) − 1  | **3,999,999**  | Quarter second                |
| 0.1 seconds     | (0.1 × 16,000,000) − 1   | **1,599,999**  | 100 ms delay                  |
| 1 millisecond   | (0.001 × 16,000,000) − 1 | **15,999**     | 1 ms delay                    |
| 10 milliseconds | (0.01 × 16,000,000) − 1  | **159,999**    | 10 ms delay                   |


SYSTICK -> CTRL
| Bit | Name      | Meaning                                          |
| --- | --------- | ------------------------------------------------ |
| 0   | ENABLE    | 1 = enable counter                               |
| 1   | TICKINT   | 1 = enable interrupt on count                    |
| 2   | CLKSOURCE | 1 = system clock, 0 = external clock (usually 1) |
| 16  | COUNTFLAG | Set to 1 when timer hits 0                       |


void SysTick_WaitMs(uint32_t ms)
{
    SYSTICK->LOAD = 16000 - 1; // 1 ms at 16 MHz
    SYSTICK->VAL = 0;
    for(uint32_t i = 0; i < ms; i++)
    {
        while((SYSTICK->CTRL & 0x10000) == 0);
    }
}
SysTick_WaitMs(2000);  // 2000 ms = 2 seconds

*/