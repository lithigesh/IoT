#include "TM4C123GH6PM.h"

// This function sets up Timer0A as a 32-bit periodic timer. It's only called once.
void Timer0A_Init(void)
{
    SYSCTL->RCGCTIMER |= 0x01;    // 1. Enable clock for Timer 0
    TIMER0->CTL = 0;             // 2. Disable Timer A during setup //Bit 8 - controls Timer0B
    TIMER0->CFG = 0x00;          // 3. Configure for 32-bit timer mode (THE FIX)
    TIMER0->TAMR = 0x02;         // 4. Configure for Periodic mode //Bit 4 - when set acts a up counter
    TIMER0->TAILR = 16000 - 1;   // 5. Set a default load value (not strictly necessary here)
    TIMER0->ICR = 0x01;          // 6. Clear the Timer A timeout flag
    TIMER0->CTL = 0x01;          // 7. Enable Timer A
}

s
// This function creates a delay of 't' milliseconds.
void delay_ms(int t)
{
    int i;
    for(i = 0; i < t; i++)
    {
        // A 1ms delay loop
        TIMER0->TAILR = 16000 - 1;    // Load value for 1ms
        TIMER0->ICR = 0x01;           // Clear the flag before waiting
        // Wait until the Timer A Raw Interrupt Status flag is set (THE FIX)
        while ((TIMER0->RIS & 0x01) == 0);
    }
}


int main(void)
{
    SYSCTL->RCGCGPIO |= 0x20;    // Enable clock for GPIO Port F
    GPIOF->DIR = 0x0E;           // Set PF1, PF2, PF3 as outputs
    GPIOF->DEN = 0x0E;           // Enable digital function for those pins

    Timer0A_Init();              // Initialize the timer once

    while(1)
    {
        GPIOF->DATA = 0x02;      // Turn on the Red LED (PF1)
        delay_ms(500);           // Delay for 500 milliseconds
        GPIOF->DATA = 0x00;      // Turn off all LEDs
        delay_ms(500);           // Delay for 500 milliseconds
    }
}

/*

| Register       | Address / Example       | Description                    | Values / Meaning                                                                                                                          |
| -------------- | ----------------------- | ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `TIMERx->CFG`  | 0x000                   | Configures overall module mode | `0x00` = 32-bit timer mode, `0x04` = 16-bit timer mode (split into A/B)                                                                   |
| `TIMERx->CTL`  | 0x00C                   | Module control                 | Bit 0 = TAEN (Enable Timer A), Bit 8 = TBEN (Enable Timer B), Bit 7 = RTCEN (Real-time clock enable), other bits reserved. Always exists. |
| `TIMERx->SYNC` | 0x010                   | Synchronize timers             | 0 = No sync, 1 = Sync with other timers                                                                                                   |
| `TIMERx->PP`   | 0xFC0                   | Peripheral properties          | Read-only, indicates max timers, 16-bit/32-bit support                                                                                    |
| `TIMERx->CC`   | 0xFC8                   | Clock configuration            | 0 = system clock, 1 = external                                                                                                            |
| `TIMERx->IMR`  | Interrupt mask register | Module-level interrupt mask    | Bits for A & B timeout, capture match events                                                                                              |


| Register              | Used For                  | Split Mode                                                      | Whole 32-bit Mode                                     |
| --------------------- | ------------------------- | --------------------------------------------------------------- | ----------------------------------------------------- |
| `TAMR` / `TBMR`       | Timer A/B mode            | Each timer has its own mode: 16-bit periodic, one-shot, capture | Only `TAMR` used for full 32-bit mode, `TBMR` ignored |
| `TAILR` / `TBILR`     | Timer A/B Interval Load   | Each timer counts independently                                 | `TAILR` holds full 32-bit interval, `TBILR` ignored   |
| `TAV` / `TBV`         | Timer A/B Current Value   | Independent counters                                            | `TAV` is 32-bit counter, `TBV` ignored                |
| `RIS` / `MIS` / `ICR` | Timer A/B flags           | Each timer can trigger interrupt individually                   | Only A timeout flag used for full 32-bit mode         |
| `TAPR` / `TBPR`       | Prescaler for fine timing | Each 16-bit timer can have prescaler                            | For full 32-bit timer, `TAPR` used for lower bits     |


32-bit Full Timer:
TIMER0->CFG   = 0x00;     // 32-bit mode (A+B)
TIMER0->TAMR  = 0x02;     // Periodic mode
TIMER0->TAILR = 32000000; // 2 seconds at 16 MHz
TIMER0->CTL   = 0x01;     // Enable Timer0A (full 32-bit)
while((TIMER0->RIS & 0x1) == 0); // Wait for timeout
TIMER0->ICR = 0x1;        // Clear timeout flag

16-bit Split Timer:
TIMER0->CFG   = 0x04;      // Split mode (16-bit A & B)
TIMER0->TAMR  = 0x02;      // Timer A periodic
TIMER0->TBMR  = 0x02;      // Timer B periodic
TIMER0->TAILR = 16000;     // 1 ms Timer A
TIMER0->TBILR = 16000;     // 1 ms Timer B
TIMER0->CTL   = 0x101;     // Enable both A & B
while((TIMER0->RIS & 0x1) == 0); // Wait for Timer A
TIMER0->ICR = 0x1;         // Clear Timer A timeout flag
while((TIMER0->RIS & (1 << 8)) == 0);  // Wait for TBTO RIS
TIMER0->ICR = (1 << 8);                 // Clear TB timeout flag



TIMER0->TAMR = 0x02;  // Periodic
TIMER0->TAMR = 0x01;  // One-shot
TIMER0->TAMR = 0x03;  // Capture

Bit 0-1: TAMR[1:0]
00 = Reserved
01 = One-shot
10 = Periodic
11 = Capture

Bit 4 (TACDIR): For periodic or one-shot, controls up/down counting
0 = Count down (default)
1 = Count up
*/