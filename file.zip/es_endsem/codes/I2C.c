SPI Master Code (TM4C123GH6PM):

#include <stdint.h>
#include "tm4c123gh6pm.h"

// Simple delay function
void delay(void)
{
    volatile int i;
    for (i = 0; i < 200000; i++);  // Rough delay loop
}

int main(void)
{
    // 1. Enable clocks for GPIO Port B and I2C0 module
    SYSCTL->RCGCGPIO |= (1 << 1);  // Enable clock for Port B (bit 1)
    SYSCTL->RCGCI2C  |= (1 << 0);  // Enable clock for I2C0 module

    // 2. Wait until both GPIOB and I2C0 modules are ready
    while ((SYSCTL->PRGPIO & (1 << 1)) == 0);  // Wait for Port B ready
    while ((SYSCTL->PRI2C  & (1 << 0)) == 0);  // Wait for I2C0 ready

    // 3. Configure Port B pins for I2C0
    GPIOB->AFSEL |= (1 << 2) | (1 << 3);  // Enable alternate functions for PB2 (SCL) and PB3 (SDA)
    GPIOB->DEN   |= (1 << 2) | (1 << 3);  // Enable digital function for PB2 and PB3
    GPIOB->ODR   |= (1 << 3);             // Enable open-drain for SDA (PB3)
    
    GPIOB->PCTL  &= ~0x0000FF00;          // Clear PCTL bits for PB2 and PB3
    GPIOB->PCTL  |=  0x00003300;          // Configure PB2 and PB3 as I2C (function 3)

    // 4. Initialize I2C0 Master
    I2C0->MCR = 0x10;     // Enable master mode (bit 4 = 1)
    I2C0->MTPR = 7;       // Set clock speed (for 100 kbps @ 16 MHz)

    while (1)
    {
        // --- Send 0x01 to Slave (LED ON) ---
        I2C0->MSA = (0x27 << 1);   // Set slave address (0x27) and write mode (LSB=0)
        I2C0->MDR = 0x01;          // Data to send (1 → LED ON)
        I2C0->MCS = 0x07;          // Start, Run, Stop (bit 2:START, bit 1:RUN, bit 0:STOP)
        while (I2C0->MCS & 1);     // Wait until busy bit clears

        delay(); // Wait a bit

        // --- Send 0x00 to Slave (LED OFF) ---
        I2C0->MSA = (0x27 << 1);   // Slave address again
        I2C0->MDR = 0x00;          // Data to send (0 → LED OFF)
        I2C0->MCS = 0x07;          // Start, Run, Stop
        while (I2C0->MCS & 1);     // Wait until done

        delay(); // Wait a bit
    }
}


SPI Slave Code (ARDUINO UNO)

#include <Wire.h>

#define SLAVE_ADDR 0x27     // I2C address (must match master)
#define LED_PIN 13          // On-board LED

void setup() {
  Wire.begin(SLAVE_ADDR);        // Join I2C bus as a slave with address 0x27
  pinMode(LED_PIN, OUTPUT);      // Set LED pin as output
  Wire.onReceive(receiveEvent);  // Register event handler when data received
}

void loop() {
  // Nothing needed here; LED control happens in receiveEvent
}

// Event triggered whenever master sends data
void receiveEvent(int howMany)
{
  while (Wire.available()) {      // While data bytes are available
    byte data = Wire.read();      // Read one byte from master
    if (data == 0x01)             // If received 0x01
      digitalWrite(LED_PIN, HIGH); // Turn LED ON
    else
      digitalWrite(LED_PIN, LOW);  // Turn LED OFF
  }
}


/*

| I²C Module | SCL Pin | SDA Pin | Port        | Alternate Function (PCTL value) |
| ---------- | ------- | ------- | ----------- | ------------------------------- |
| **I2C0**   | PB2     | PB3     | GPIO Port B | 3                               |
| **I2C1**   | PA6     | PA7     | GPIO Port A | 3                               |
| **I2C2**   | PE4     | PE5     | GPIO Port E | 3                               |
| **I2C3**   | PD0     | PD1     | GPIO Port D | 3                               |

*/