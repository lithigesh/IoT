#include "TM4C123GH6PM.h"

// This function creates a delay of 't' milliseconds using a 16-bit timer.
void delay_ms(int t)
{
    // Re-configure the timer for a 1ms delay on each call
    TIMER0->CTL = 0;              // Disable Timer A
    TIMER0->TAILR = 16000 - 1;    // Load value for 1ms (16000 cycles @ 16MHz)
    TIMER0->ICR = 0x01;           // Clear the timeout flag
    TIMER0->CTL = 0x01;           // Enable Timer A

    // Loop 't' times to create the total delay
    for(int i = 0; i < t; i++)
    {
        // Wait until the 1ms timer has timed out
        while ((TIMER0->RIS & 0x01) == 0);
        TIMER0->ICR = 0x01; // Clear the flag for the next loop iteration
    }
}


int main(void)
{
    int c = 0;

    // --- One-time Setup ---
    SYSCTL->RCGCGPIO |= 0x20;     // Enable clock for GPIO Port F
    GPIOF->DIR = 0x0E;            // Set PF1, PF2, PF3 as outputs
    GPIOF->DEN = 0x0E;            // Enable digital function for those pins

    // --- Timer Setup (done only once) ---
    SYSCTL->RCGCTIMER |= 0x01;    // Enable clock for Timer 0
    TIMER0->CTL = 0;              // Disable Timer A during setup
    TIMER0->CFG = 0x04;           // Configure for 16-bit timer mode
    TIMER0->TAMR = 0x02;          // Configure for Periodic mode

    while(1)
    {
        GPIOF->DATA = c << 1;     // Display counter on LEDs (PF1, PF2, PF3)
        c = (c + 1) % 8;          // Increment 3-bit counter (0-7)
        delay_ms(2000);           // Delay for 2000 milliseconds (2 seconds)
    }
}