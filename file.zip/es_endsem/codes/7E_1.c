#include "TM4C123GH6PM.h"

int main(void)
{
    int c = 0;
    SYSCTL -> RCGCGPIO |= 0x20;
    GPIOF -> DIR = 0x0E;
    GPIOF -> DEN = 0x0E;

    SYSTICK -> LOAD = 16000000 - 1;
    SYSTICK -> CTRL = 5;

    while(1)
    {
        if (SYSTICK -> CTRL & 0x10000)
        {
                GPIOF -> DATA = c << 1;
                c = (c + 1)%4;
        }
    }
}