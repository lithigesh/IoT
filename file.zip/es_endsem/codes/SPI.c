//Transmits character A and B with delay of 1 second
#include "tm4c123gh6pm.h"

void SPI1_Init(void);
void SPI1_write(unsigned char data);
void delay_Ms(int time_ms);

int main(void)
{
	unsigned char val1='A';
	unsigned char val2='B';
	
	SPI1_Init();
	while(1)
	{
		SPI1_write(val1);   // write a character
		delay_Ms(1000);
		
		SPI1_write(val2);   // write a character
		delay_Ms(1000);
	}
}

void SPI1_Init(void)
{
	//Enable clk to SPI1, GPIOD, GPIOF
	
	SYSCTL -> RCGCSSI |= (1<<1);  //set clk enabling bit for SPI1
	SYSCTL -> RCGCGPIO |= (1<<3); //enable clk to GPIOD for SPI1
	SYSCTL -> RCGCGPIO |= (1<<5); //enable clk to GPIOF for SS
	
	
	//initialise PD3 and PD0 for SPI1 alternate function
	
	GPIOD -> AMSEL &= ~0X09;  //disable analog functionality for RD0 & RD3
	GPIOD -> DEN |= 0X09;   //set RD0 and RD3 as digital pin
	GPIOD -> AFSEL |= 0X09;  //enable alternate function of RD0 and RD3
	GPIOD -> PCTL &= ~0X0000F00F;   //assign RD0 and Rd3 pins to SPI1
	GPIOD -> PCTL |= 0X00002002;  ////assign RD0 and Rd3 pins to SPI1
	
	// initialise PF2 as digital o/p as a slave select pin
	GPIOF -> DEN |= (1<<2);   //set PF2 as digital pin
	GPIOF -> DIR |= (1<<2);   // set PF2 pin o/p
	GPIOF -> DATA |= (1<<2);  //keep SS idle high
	
	//Select SPI1 as a master, POL=0,  PHA=0,   clock=4 MHz,  8 bit data
	SSI1 -> CR1 = 0;   //Disable SPI1 and configure it as a master
	SSI1 -> CC = 0;   //enable system clk option
	SSI1 -> CPSR = 4;  //select pre scalar value of 4 i.e. 16 MHz /4 = 4MHz
	SSI1 -> CR0 = 0X00007;   //4MHz SPI1 clk, SPI mode, 8 bit data
	SSI1 -> CR1 |= 2;    //enable SPI1
}
	
void SPI1_write(unsigned char data)
{
	GPIOF -> DATA &= ~(1<<2);   //Make PF2 selection line (SS) LOW
	while((SSI1 -> SR & 2) ==0);  //wait until Tx FIFO is not full
	
	SSI1 -> DR = data;   //transmit byte over SSI1Tx line
	while(SSI1 -> SR & 0X10);   //wait until transmit complete 
	
	GPIOF -> DATA |= 0X04;	//keep selection line(PF2) high in idle condition
}
	
void delay_Ms(int time_ms)
{
	int i,j;
	for (i=0; i<time_ms ;i++)
		for(j=0; j<3180; j++)
	{}
}

/* USE THIS ONLY WHEN USING OLDER VERSION OF KEIL MICRO VISION
void SystemInit(void)
{
	SCB -> CPACR |= 0X00F00000;
}
*/


/*
ARDUINO

# include <SPI.h>
#define LEDpin 7
volatile boolean received;
char Slavereceived;

void setup() {
  
  Serial.begin(9600);   
  pinMode(LEDpin, OUTPUT);  //setting pin 7 as o/p
  SPCR |= (1<<SPE) | (1<<SPIE);   //turn on SPI in slave mode
  received = false;
  SPI.attachInterrupt();    //Interrupt ON is set for SPI communicatio
  sei();

}
ISR(SPI_STC_vect)     //interrupt routine function
{
  Slavereceived = SPDR;   //value received from master if store in variable Slavereceived
  received = true;   //set received as true
} 

void loop() {
  if (received)  // Logic to set LED ON or OFF depending upon value received from master
  {
    if (Slavereceived == 'A')
    {
      digitalWrite (LEDpin, HIGH);
      Serial.println("Slave LED ON");
      Serial.println(Slavereceived);
    }
    else
    {
      digitalWrite (LEDpin, LOW);
      Serial.println("Slave LED OFF");
      Serial.println(Slavereceived);
    }
  }
  delay(1000);

}
*/


/*

#include "tm4c123gh6pm.h"

void SPI1_Init(void);
unsigned char SPI1_Transfer(unsigned char data);
void delay_Ms(int time_ms);

int main(void)
{
    unsigned char command = 'R';  // Request command
    unsigned char sensorValue = 0;

    SPI1_Init();

    while (1)
    {
        GPIOF->DATA &= ~(1<<2);   // SS LOW (select slave)
        sensorValue = SPI1_Transfer(command);  // send command & receive data
        GPIOF->DATA |= (1<<2);    // SS HIGH

        // Here sensorValue contains ADC data (0–255)
        // You can display or debug using UART or logic analyzer

        delay_Ms(1000);  // 1 second delay
    }
}

void SPI1_Init(void)
{
    // Enable Clocks for SSI1 and GPIO Ports D & F
    SYSCTL->RCGCSSI |= (1<<1);
    SYSCTL->RCGCGPIO |= (1<<3) | (1<<5);

    // Wait for the peripherals to be ready
    while((SYSCTL->PRGPIO & (1<<3)) == 0);
    while((SYSCTL->PRGPIO & (1<<5)) == 0);

    // Configure PD0, PD2, PD3 for SSI1 alternate functions
    GPIOD->AFSEL |= (1<<0)|(1<<2)|(1<<3);
    GPIOD->PCTL &= ~0x0000F0FF;   // clear bits for PD0,2,3
    GPIOD->PCTL |= 0x00002202;    // PD0-CLK, PD2-Rx, PD3-Tx
    GPIOD->DEN  |= (1<<0)|(1<<2)|(1<<3);
    GPIOD->AMSEL &= ~((1<<0)|(1<<2)|(1<<3));

    // PF2 as SS (manual control)
    GPIOF->DIR |= (1<<2);
    GPIOF->DEN |= (1<<2);
    GPIOF->DATA |= (1<<2); // keep SS high initially

    // Configure SSI1
    SSI1->CR1 = 0;            // disable SSI & configure as master
    SSI1->CC = 0;             // use system clock (16 MHz)
    SSI1->CPSR = 8;           // prescale ÷8 → 2 MHz
    SSI1->CR0 = 0x07;         // 8-bit data, Freescale SPI mode 0
    SSI1->CR1 |= 0x02;        // enable SSI
}

unsigned char SPI1_Transfer(unsigned char data)
{
    while((SSI1->SR & 0x02) == 0); // wait until Tx FIFO not full
    SSI1->DR = data;               // send data
    while((SSI1->SR & 0x04) == 0); // wait until Rx FIFO not empty
    return (unsigned char)SSI1->DR; // return received byte
}

void delay_Ms(int time_ms)
{
    int i, j;
    for(i = 0; i < time_ms; i++)
        for(j = 0; j < 3180; j++);
}



#include <SPI.h>

volatile byte command;
volatile boolean received = false;

int sensorPin = A0;  // analog input pin
byte sensorValue = 0;

ISR(SPI_STC_vect)
{
  command = SPDR;   // read data from master
  received = true;  // mark data as received
}

void setup()
{
  Serial.begin(9600);

  pinMode(MISO, OUTPUT);  // set MISO as output
  SPCR |= _BV(SPE) | _BV(SPIE); // enable SPI + interrupt

  sei();  // enable global interrupts
}

void loop()
{
  if (received)
  {
    received = false;

    if (command == 'R')  // If master requests data
    {
      int analogVal = analogRead(sensorPin);     // read sensor (0-1023)
      sensorValue = analogVal / 4;               // convert to 8-bit (0–255)
      SPDR = sensorValue;                        // send next byte to master
      Serial.print("Sent ADC Value: ");
      Serial.println(sensorValue);
    }
    else
    {
      SPDR = 0;  // default response
    }
  }
}
*/