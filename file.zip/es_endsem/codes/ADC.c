#include <stdint.h>         // Standard library for fixed-width integer types like uint32_t.
#include "TM4C123GH6PM.h"    // Header file specific to the TM4C123GH6PM microcontroller.

uint32_t result; // Global variable to store the raw ADC result.

// Initializes ADC0 to read from the internal temperature sensor using Sample Sequencer 3.
void ADC0_init(void)
{
    // --- Clock Configuration ---
    SYSCTL->RCGCADC |= 0x01;       // 1. Enable the clock for the ADC0 module.

    // --- Wait for the ADC to be ready ---
    while((SYSCTL->PRADC & 0x01) == 0);

    // --- ADC Configuration for Temperature Sensing ---
    ADC0->ACTSS &= ~(1 << 3);    // 2. Disable Sample Sequencer 3 (SS3) before making changes.
    ADC0->EMUX &= ~0xF000;       // 3. Set SS3 trigger source to "Processor" (software-initiated).
    ADC0->SSMUX3 = 0;            // 4. Select internal input. For the temp sensor, this must be 0.
    
    // 5. Configure the control settings for the sample.
    //    Bit 3 (TS0): Selects the internal temperature sensor as the input source.
    //    Bit 1 (END0): Marks this as the first and last sample in the sequence.
    //    Bit 2 (IE0) can also be set to enable interrupts, but is not needed for polling.
    ADC0->SSCTL3 = (1 << 3) | (1 << 1); 

    ADC0->ACTSS |= (1 << 3);     // 6. Re-enable Sample Sequencer 3 after configuration.
}

// Starts a conversion on ADC0 SS3, waits for it to complete, and returns the result.
uint32_t ADC0_Read(void)
{
    // 1. Start a conversion on Sample Sequencer 3.
    ADC0->PSSI |= (1 << 3);
    
    // 2. Wait until the conversion is complete by polling the Raw Interrupt Status flag.
    while((ADC0->RIS & (1 << 3)) == 0);
    
    // 3. Read the 12-bit digital result from the sequencer's FIFO buffer.
    result = ADC0->SSFIFO3;
    
    // 4. Clear the conversion complete flag to prepare for the next read.
    ADC0->ISC = (1 << 3);
    
    // 5. Return the raw ADC value.
    return result; 
}

// Initializes Port F, Pin 3 (Green LED) as a digital output.
void PortF_Init(void)
{
    SYSCTL->RCGCGPIO |= (1 << 5);         // Enable clock for GPIO Port F.
    while((SYSCTL->PRGPIO & 0x20) == 0);  // Wait for Port F to be ready.
    // NOTE: LOCK and CR registers are not needed for PF3.
    GPIOF->DIR |= (1 << 3);               // Set PF3 (Green LED) as an output.
    GPIOF->DEN |= (1 << 3);               // Enable digital functionality for PF3.
}

// A simple software-based delay function. Not precise.
void delayMs(int n)
{
    int i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < 3180; j++) {} // This inner loop is roughly 1ms on a 16MHz clock.
    }
}


int main(void)
{
    // --- One-Time Initialization ---
    ADC0_init();  // Set up the ADC for temperature sensing.
    PortF_Init(); // Set up the GPIO for the LED.

    // --- Main Application Loop ---
    while(1)
    {
        // 1. Read the raw 12-bit value from the ADC.
        uint32_t adc_value = ADC0_Read();
        
        // 2. Convert the raw ADC value to degrees Celsius using the formula from the datasheet.
        float temp_c = 147.5 - ((75.0 * adc_value) / 4096.0);
        
        // 3. Control the Green LED based on the temperature.
        if (temp_c > 25.0) // Example threshold of 25°C
        {
            GPIOF->DATA |= (1 << 3); // Turn the Green LED ON.
        }
        else
        {
            GPIOF->DATA &= ~(1 << 3); // Turn the Green LED OFF.
        }
        
        // 4. Wait for 500ms before taking the next reading.
        delayMs(500);
    }
}

/*
1. ACTSS
| Bit | Sequencer | Description   |
| --- | --------- | ------------- |
| 0   | SS0       | 8 samples max |
| 1   | SS1       | 4 samples max |
| 2   | SS2       | 4 samples max |
| 3   | SS3       | 1 sample max  |


2. EMUX
| Bits [15:12] for SS3 | Meaning                              |
| -------------------- | ------------------------------------ |
| 0x0                  | Processor (software trigger)         |
| 0x1                  | Analog comparator 0                  |
| 0x2                  | External GPIO trigger                |
| 0xF                  | Continuous sampling (always trigger) |

3. SSCTL3

| Bit | Name | Function                             |
| --- | ---- | ------------------------------------ |
| 3   | TS0  | Use internal temp sensor             |
| 2   | IE0  | Interrupt enable (optional)          |
| 1   | END0 | Marks end of sequence                |
| 0   | D0   | Differential mode enable (usually 0) |

*/