#include <stdint.h>             // Standard library for fixed-width integer types like uint8_t.
#include "TM4C123GH6PM.h"    // Header file specific to the TM4C123GH6PM microcontroller, defining all register addresses.

// A simple software delay function.
void delay(int j)
{
    while(j--); // Loop 'j' times to create a pause.
}

// Function to receive one character via UART0.
char Rx(void)
{
    char c;
    // Wait until the receiver FIFO is not empty by checking the RXFE flag (bit 4) in the Flag Register (FR).
    while((UART0->FR & 0x10) != 0);
    c = UART0->DR; // Read the received character from the Data Register (DR).
    return c;      // Return the character.
}

// Function to transmit one character via UART0.
void Tx(char c)
{
    // Wait until the transmitter FIFO is not full by checking the TXFF flag (bit 5) in the Flag Register (FR).
    while((UART0->FR & 0x20) != 0);
    UART0->DR = c; // Write the character to the Data Register (DR) to be sent.
}

int main(void)
{
    char c; // Variable to store the received character.
    char v; // Variable to store the state of the switch.

    //----------- CLOCK CONFIGURATION -----------//
    SYSCTL->RCGCUART |= 0x01;  // 1. Enable the clock for UART0 module.
    SYSCTL->RCGCGPIO |= 0x01;  // 2. Enable the clock for GPIO Port A (for UART pins).
    SYSCTL->RCGCGPIO |= 0x20;  // 3. Enable the clock for GPIO Port F (for switch and LEDs).

    //----------- PERIPHERAL READY CHECK -----------//
    // Wait until both GPIO Port A and Port F are ready.
    while((SYSCTL->PRGPIO & 0x21) != 0x21);
    // Wait until the UART0 module is ready.
    while((SYSCTL->PRUART & 0x01) != 0x01);

    //----------- UART0 CONFIGURATION -----------//
    UART0->CTL = 0;           // Disable UART0 before making changes.
    UART0->IBRD = 104;        // Set the Integer Baud-Rate Divisor for 9600 bps.
    UART0->FBRD = 11;         // Set the Fractional Baud-Rate Divisor for 9600 bps.
    UART0->CC = 0x5;          // Use the Precision Internal Oscillator (PIOSC) as the clock source.
    UART0->LCRH = 0x60;       // Configure for 8-bit word length, no parity, 1 stop bit, FIFOs disabled.
    UART0->CTL = 0x301;       // Re-enable UART0, along with its transmitter (TXE) and receiver (RXE).

    //----------- GPIO PORT A (UART PINS) CONFIGURATION -----------//
    GPIOA->DEN |= 0x03;       // Enable digital functionality for PA0 (U0RX) and PA1 (U0TX).
    GPIOA->AFSEL |= 0x03;     // Enable alternate function for PA0 and PA1.
    GPIOA->PCTL &= ~(0xFF);   // Clear the PCTL bits for PA0 and PA1 to ensure a clean slate.
    GPIOA->PCTL |= 0x11;      // Assign the UART function (alternate function 1) to PA0 and PA1.
    GPIOA->AMSEL &= ~(0x03);  // Disable analog functionality on PA0 and PA1.

    //----------- GPIO PORT F (SWITCH & LED) CONFIGURATION -----------//
    GPIOF->DIR &= ~(1 << 4);   // Set the direction for PF4 (SW1) as input.
    GPIOF->DIR |= 0x0E;        // Set the direction for PF1, PF2, PF3 (LEDs) as output.
    GPIOF->DEN |= 0x1E;        // Enable digital functionality for PF1, PF2, PF3, and PF4.
    GPIOF->PUR |= (1 << 4);    // Enable the internal pull-up resistor for PF4 (SW1).
    GPIOF->DATA = 0;           // Initialize the LED data register to turn off all LEDs.

    //----------- MAIN LOOP -----------//
    while(1)
    {
        c = Rx(); // Wait for and receive a character from the PC.

        // Check the state of the switch SW1 (PF4)
        v = GPIOF->DATA & 0x10; // Read the data register and mask to get only the state of PF4.
        v = v >> 4;             // Right-shift the result by 4 to get either 0 or 1.

        // If the pull-up resistor is enabled, a button press grounds the pin, making its state 0.
        if (v == 0)
        {
            Tx(c); // Transmit the character back only if SW1 is pressed.
        }
    }
}

/*


BRD = Clock / (16 * Baud)
IBRD = Int(BRD)
FBRD = Frac(BRD)*64 + 0.5

|  UART | RX Pin | TX Pin |  Port  | Alternate Function |
| :---: | :----: | :----: | :----: | :----------------: |
| UART0 |   PA0  |   PA1  | Port A |         AF1        |
| UART1 |   PB0  |   PB1  | Port B |         AF1        |
| UART2 |   PD6  |   PD7  | Port D |         AF1        |
| UART3 |   PC6  |   PC7  | Port C |         AF1        |
| UART4 |   PC4  |   PC5  | Port C |         AF1        |
| UART5 |   PE4  |   PE5  | Port E |         AF1        |
| UART6 |   PD4  |   PD5  | Port D |         AF1        |
| UART7 |   PE0  |   PE1  | Port E |         AF1        |


void UART0_TxString(char *str)
{
    while(*str)  // Loop until null terminator
    {
        Tx(*str);
        str++;
    }
}
UART0_TxString("Hello from TM4C123!\r\n");


#include <stdio.h> // for sprintf

int value = 1234;
char buffer[10];
sprintf(buffer, "%d\r\n", value);
UART0_TxString(buffer);

*/