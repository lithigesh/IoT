#include "tm4c123gh6pm.h"

void SPI1_init(void);
void SPI1_Read(void);
void UART0_init(void);
void UART0_Read(void);
void UART0_Write(char data);
void delay_Ms(int i);

int main(void){
    char recieved_char;
    char sensorValue;

    SYSCTL->RCGCGPIO |= (1<<5);
    GPIOF->DIR|=(1<<2)|(1<<1);
    GPIOF->DEN|=(1<<2)|(1<<1);
    GPIOF->DATA|=(1<<2);

    SPI1_init();
    UART0_init();

    while(1){
        recieved_char = UART0_Read();

        if(recieved_char=='p'){
            GPIOF->DATA|= ~(1<<2);
            sensorValue = SPI1_Read();
            GPIOF->DATA|=(1<<2);

            if(sensorValue<500){
                GPIOF->DATA|=(1<<1);
            }else{
                GPIOF->DATA&=~(1<<1);
            }
        }
        delay_Ms(500);
    }
}

void SPI1_init(void) {
    SYSCTL->RCGCSSI |= (1<<1);     
    SYSCTL->RCGCGPIO |= (1<<3);    

    GPIOD->AFSEL |= 0x0F;           
    GPIOD->DEN   |= 0x0F;           
    GPIOD->AMSEL &= ~0x0F;          
    GPIOD->PCTL  &= ~0xFFFF;        
    GPIOD->PCTL  |= 0x2222;        

    SSI1->CR1 = 0;               
    SSI1->CC = 0;                  
    SSI1->CPSR = 16;               
    SSI1->CR0 = 0x07;               
    SSI1->CR1 = 0x02;             
}

char SPI1_Read(void){
    SSI1->DR=0xFF;
    while((SSI1->SR & (1<<4)));
    reutrn (chat)SSI1->DR &0xFF;
}

void UAER0_init(void){
    SYSCTL->RCGCUART|=(1<<0);
    SYSCTL->RCGCGPIO|=(1<<0);
    UART0->CTL=0;
    UART0->IBRD=104;
    UART0->FBRD=11;
    UART0->CC=0;
    UART0->LCRH=0X60;
    UART0->CTL=0X301;

    GPIOA->DEN|=0X03;
    GPIOA->AFSEL|=0X03;
    GPIOA->PCTL|=0X11;
}

coid UART0_Read(void){
    while((UART0->FR & 0X10) != 0);
    return UART0->DR;
}

void UART0_Write(char data){
    while((UART0->FR & 0X20) != 0);
    UART0->DR = data;
}

void delay_Ms(int time_ms) {
    int i,j;
    for(i=0;i<time_ms;i++)
        for(j=0;j<3180;j++);
}
