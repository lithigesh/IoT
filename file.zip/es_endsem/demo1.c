#include <SPI.h>

#define IRSensor A0
char dataToSend;

void setup(){
    pinMode(IRSensor, INPUT);
    pinMode(MISO,OUTPUT);

    SPCR |= _BV(SPE);
    SPI.attachInterrupt();

    serial.Begin(9600);
    delay(500);
    Seerial.println("SPI");
}

void loop(){
    int sensorvalue = analogRead(IRSensor);

    dataToSend = sensorvalue;
}

ISR(SPI_STC_Vect){
    SPDR=dataToSend;
}