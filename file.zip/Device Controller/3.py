from  sense_hat import SenseHat
from time import sleep
from time import asctime
from flask import Flask,render_template
sense = SenseHat()

app=Flask(__name__)
@app.route("/")


def index():
    deviceSts = "OFF"
    sense.show_letter("I")
    templateData = {
        'device1' : deviceSts
    }
    return render_template('index.html',**templateData)

@app.route("/<deviceName>/<action>")
def action(deviceName, action):
    if deviceName == 'd1' and action == 'on':
        deviceSts = "ON"
        sense.show_letter("O")
    if deviceName == 'd1' and action == 'off':
        deviceSts = "OFF"
        sense.clear()
    templateData = {
         'device1' : deviceSts   
    }
    return render_template('index.html',**templateData)
        

@app.route("/off")

def clear():
    deviceSts = "OFF"
    sense.clear()
    templateData = {
        'device1' : deviceSts
    }
    return render_template('index.html',**templateData)

if __name__=='__main__':
    app.run(host='172.17.126.103')
    


from sense_hat import SenseHat
from time import sleep
from time import asctime
from flask import Flask, render_template

sense=SenseHat()

app=Flask(__name__)
@app.route("/")

def index():
    deviceSts = "OFF"
    sense.show_letter("I")
    templateData ={
        "device1": deviceSts
    }
    return render_template("index.html",**templateData)

@app.route("/<deviceName>/<action>")
def action(deviceName,action):
    if deviceName=="d1" and action=="on":
        deviceSts = "ON"
        sense.show_letter("O")
    elif deviceName=="d1" and action=="off":
        deviceSts = "OFF"
        sense.show_letter("N")
    templateData = {"device1" : deviceSts}
    return render_template("index.html", **templateData)

@app.route("/OFF")
def clear():
    deviceSts="OFF"
    sense.clear()
    templateData={"device1": deviceSts}
    return render_template("index.html",**templateData)

if __name__ == '__main__':
    app.run(host='172.17.126.103')










from flask import Flask,render_template
from sense_hat import Sensehat

sense=SenseHat()
app=Flask(__name__)

deviceSts = "OFF"

@app.route('/')

def index():
    templateData= {"device1": deviceSts}
    return render_template('index.html',**templateData)

@app.route('/send/temperature')
def send_temperature():
    temperature=round(sense.get_temperature(),2)
    print(f"temperature sent : {temperature}")
    return render_template('index.html',device1=f"Temperature : {temperature}")

@app.route('/send/pressure')
def send_pressure():
    pressure=round(sense.get_pressure(),2)
    print(f"pressure sent : {pressure}")
    return render_template('index.html',device1=f"pressure : {pressure}")


@app.route('/send/temperature/pressure')
def send_temperature_pressure():
    temperature=round(sense.get_temperature(),2)
    pressure=round(sense.get_pressure(),2)
    print(f"temperature sent : {temperature} pressure sent: {pressure}")
    return render_template('index.html',device1=f"Temperature : {temperature}, pressure : {pressure}")


if __name__=='__main__':
    app.run(host='172.17.126.103')