

import RPi.GPIO as GPIO
import requests
import time

# --- GPIO Setup ---
LED_PIN = 32
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(LED_PIN, GPIO.OUT)

led_pwm = GPIO.PWM(LED_PIN, 100)  # 100 Hz PWM
led_pwm.start(0)

# --- ThingSpeak Setup ---
READ_API_KEY = "YOUR_READ_API_KEY"   # from ThingSpeak
CHANNEL_ID = "YOUR_CHANNEL_ID"

URL = f"https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds/last.json?api_key={READ_API_KEY}"

led_status = "OFF"
brightness = 0

try:
    while True:
        # --- Get latest data from ThingSpeak ---
        response = requests.get(URL)
        data = response.json()

        toggle = data["field1"]   # 0 or 1
        bright = data["field2"]   # 0–100

        if toggle is not None:
            toggle = int(toggle)
        if bright is not None:
            bright = int(bright)

        # --- Control LED ---
        if toggle == 1:
            led_status = "ON"
            brightness = bright
            led_pwm.ChangeDutyCycle(brightness)
            print(f"LED ON, Brightness {brightness}%")
        else:
            led_status = "OFF"
            led_pwm.ChangeDutyCycle(0)
            print("LED OFF")

        time.sleep(5)  # check every 5 sec

except KeyboardInterrupt:
    print("Exiting...")
    led_pwm.stop()
    GPIO.cleanup()




import sys
import RPi.GPIO as GPIO
from Adafruit_IO import MQTTClient

# --- Adafruit IO Setup ---
ADAFRUIT_IO_USERNAME = "your_username"
ADAFRUIT_IO_KEY = "your_aio_key"
FEED_TOGGLE = "led_toggle"
FEED_BRIGHTNESS = "led_brightness"

# --- GPIO Setup ---
LED_PIN = 32
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(LED_PIN, GPIO.OUT)

pwm = GPIO.PWM(LED_PIN, 100)  # 100 Hz
pwm.start(0)

led_status = "OFF"
brightness = 0

# --- Callbacks ---
def connected(client):
    print("Connected to Adafruit IO! Listening for changes...")
    client.subscribe(FEED_TOGGLE)
    client.subscribe(FEED_BRIGHTNESS)

def disconnected(client):
    print("Disconnected from Adafruit IO!")
    sys.exit(1)

def message(client, feed_id, payload):
    global led_status, brightness

    print(f"Feed {feed_id} received value: {payload}")

    if feed_id == FEED_TOGGLE:
        if payload == "1":
            led_status = "ON"
            pwm.ChangeDutyCycle(brightness)
            print("LED ON")
        else:
            led_status = "OFF"
            pwm.ChangeDutyCycle(0)
            print("LED OFF")

    elif feed_id == FEED_BRIGHTNESS:
        try:
            brightness = int(payload)
            if led_status == "ON":
                pwm.ChangeDutyCycle(brightness)
                print(f"LED brightness set to {brightness}%")
            else:
                print("LED is OFF (brightness stored)")
        except ValueError:
            print("Invalid brightness value")

# --- MQTT Client ---
client = MQTTClient(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)
client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message
client.connect()
client.loop_blocking()