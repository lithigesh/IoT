from  sense_hat import SenseHat
from time import sleep
from time import asctime
from flask import Flask,render_template
sense = SenseHat()

app=Flask(__name__)
@app.route("/")

def index():
    now=str(asctime())
    temp=round(sense.get_temperature()*1.8+32)
    humidity=round(sense.get_humidity())
    pressure = round(sense.get_pressure())
    message="Temperature is %d F ...Humidity is %d percent ... Pressure is %d mbars"%(temp,humidity,pressure)
    currentWeather=now + "-" + message + "\n"

    weatherData={'weather':currentWeather}
    #return currentWeather
    return render_template('index.html',**weatherData)
#sense.show_message(message,scroll_speed=(0.08),text_colour=[200,0,200],back_colour=[0,0,0])
sense.clear()

if __name__=='__main__':
    app.run(host='172.17.126.103')








from  sense_hat import SenseHat
from time import sleep
from time import asctime
from flask import Flask,render_template
sense = SenseHat()

app=Flask(__name__)
@app.route("/")

def index():
    now=str(asctime())
    temp=round(sense.get_temperature()*1.8+32)
    humidity=round(sense.get_humidity())
    pressure = round(sense.get_pressure())
    message="Temperature is %d F ...Humidity is %d percent ... Pressure is %d mbars"%(temp,humidity,pressure)
    currentWeather=now + "-" + message + "\n"
    for event in sense.stick.get_events():
        if event.action=="held" and event.direction=="middle":
            weatherData={'weather':currentWeather}
        else:
            weatherData={'weather':None}

    
    #return currentWeather
    return render_template('index.html',**weatherData)
#sense.show_message(message,scroll_speed=(0.08),text_colour=[200,0,200],back_colour=[0,0,0])
sense.clear()

if __name__=='__main__':
    app.run(host='172.17.126.103')




from sense_hat import SenseHat
from flask import Flask, render_template
from time import asctime

sense = SenseHat()
sense.clear()
app = Flask(__name__)

# Global flag to indicate middle button is held
send_weather = False

# Function to poll joystick events in the background
def check_joystick():
    global send_weather
    for event in sense.stick.get_events():
        if event.action == "held" and event.direction == "middle":
            send_weather = True
        else:
            send_weather = False

@app.route("/")
def index():
    global send_weather
    check_joystick()  # check joystick state
    if send_weather:
        now = str(asctime())
        temp = round(sense.get_temperature()*1.8+32)
        humidity = round(sense.get_humidity())
        pressure = round(sense.get_pressure())
        message = f"Temperature is {temp} F ... Humidity is {humidity} percent ... Pressure is {pressure} mbars"
        currentWeather = now + " - " + message
        weatherData = {'weather': currentWeather}
    else:
        weatherData = {'weather': None}
    return render_template('index.html', **weatherData)

if __name__=='__main__':
    app.run(host='172.17.126.103')




from flask import Flask, render_template
from sense_hat import SenseHat
from time import asctime

sense = SenseHat()
app = Flask(_name_)

# Shared variable to store weather data
weatherData = {'weather': None}

# Route to display the latest weather data
@app.route('/')
def index():
    return render_template('web.html', **weatherData)

# Background function to monitor joystick
def joystick_listener():
    global weatherData
    while True:
        for event in sense.stick.get_events():
            if event.action == "pressed" and event.direction == "right":
                now = asctime()
                temp = round(sense.get_temperature()*1.8 + 32, 1)  # Fahrenheit
                humidity = round(sense.get_humidity(), 1)
                pressure = round(sense.get_pressure(), 1)
                message = f'Temp: {temp}°F, Humidity: {humidity}%, Pressure: {pressure} mbars'
                currentWeather = now +""+"-"+message+"\n"
                log=open("log.txt","a")
                log.write(currentWeather)
                log.close()
                
                # Update shared data
                weatherData = {'weather':currentWeather}
                print(f' Weather updated: {currentWeather}')

if _name_ == '_main_':
    import threading
    # Start joystick monitoring in a background thread
    joystick_thread = threading.Thread(target=joystick_listener, daemon=True)
    joystick_thread.start()
    
    # Start Flask server
    app.run(host= '172.17.126.32')



from flask import Flask,render_template
import time
from time import asctime
import random
from sense_hat import SenseHat

sense=SenseHat()
sense.clear()
app=Flask(__name__)

@app.route("/")
def index():
    now=str(asctime())
    temperature=round(sense.get_temperature(),2)
    pressure=round(sense.get_pressure(),2)
    humidity=round(sense.get_humidity(),2)
    message=f"temperature is {temperature} F, pressure is {pressure} mbars, humidity is {humidity} percent"
    currentWeather=now+'-'+ message+"\n"
    log.open("log.txt","a")
    log.write("currentWeather")
    log.close()
    weatherData={"Weather":currentWeather}
    return render_template('index.html',**weatherData)

if __name__=='__main__':
    app.run(host='172.17.126.103')
